# Route 420 — Super Simple Static Site (Render)

This is a single-file site (`index.html`) with Tailwind via CDN. No build step. Perfect for **Render → Static Site**.

## Quick Deploy on Render
1. Push this folder to a new GitHub repo (or just upload the zip in a repo).
2. In **Render**: **New → Static Site**.
3. Connect your repo.
4. **Build Command:** *(leave empty)*
5. **Publish Directory:** `/` (root)
6. Deploy.

### Custom Domain
- Add your domain in Render → Custom Domains.
- Set a DNS **CNAME** from `www.yourdomain.com` → your `*.onrender.com` URL.
- Optionally add an apex (`yourdomain.com`) with ANAME/ALIAS if your DNS supports it.

### Editing Content
- Open `index.html` and replace:
  - Address/phone/email in the **Visit** section.
  - Social links.
  - Gallery/Drops images (swap URLs).
  - Update titles/excerpts.
  - YouTube embed IDs in **Video Hub** (replace the `src` URL IDs).

### Livestream (Twitch)
- Twitch requires the `parent` query param to match your exact domain.
- Easiest path: embed YouTube in this simple file.
- If you must embed Twitch here, you can replace one of the iframes with:
  ```html
  <iframe src="https://player.twitch.tv/?channel=YOURCHANNEL&parent=YOURDOMAIN.com"
          allowfullscreen frameborder="0" class="w-full h-full"></iframe>
  ```
- Use your temporary `onrender.com` host during testing, then update to your real domain later.

### Notes
- Keep the age-gate for compliance.
- Images are from Unsplash placeholders—replace with your photos.
- Because this is a **single page**, you don’t need SPA rewrites.
- You can later migrate to Next.js or add a CMS without changing your domain.
